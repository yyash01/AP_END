package EHMS;

public class Payment {

}
